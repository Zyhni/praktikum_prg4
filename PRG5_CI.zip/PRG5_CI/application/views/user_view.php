<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <title>Data User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            margin-right: 10px;
        }

        .jarakbutton {
            margin-top: 15px;
        }

        .jarakbutton2 {
            margin-left: 20px;
        }
    </style>
        <meta charset="utf-8">
    <title>IZWIN - Toko Hewan terbaik</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="<?= base_url ('https://fonts.gstatic.com') ?>">
    <link href="<?= base_url ('https://fonts.googleapis.com/css2?family=Poppins&family=Roboto:wght@700&display=swap') ?>" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="<?= base_url ('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css') ?>" rel="stylesheet">
    <link href="<?= base_url ('lib/flaticon/font/flaticon.css" rel="stylesheet') ?>">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url ('lib/owlcarousel/assets/owl.carousel.min.css') ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url ('css/bootstrap.min.css') ?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= base_url ('css/style.css') ?>" rel="stylesheet">
</head>

<body>
<div class="container-fluid border-bottom d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-4 text-center py-2">
                <div class="d-inline-flex align-items-center">
                    <i class="bi bi-geo-alt fs-1 text-primary me-3"></i>
                    <div class="text-start">
                        <h6 class="text-uppercase mb-1">Our Office</h6>
                        <span>Grand Residence, Bekasi, Indonesia</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 text-center border-start border-end py-2">
                <div class="d-inline-flex align-items-center">
                    <i class="bi bi-envelope-open fs-1 text-primary me-3"></i>
                    <div class="text-start">
                        <h6 class="text-uppercase mb-1">Email Us</h6>
                        <span>lordzihni@gmail.com</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 text-center py-2">
                <div class="d-inline-flex align-items-center">
                    <i class="bi bi-phone-vibrate fs-1 text-primary me-3"></i>
                    <div class="text-start">
                        <h6 class="text-uppercase mb-1">Call Us</h6>
                        <span>+62 895-0478-3789</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm py-3 py-lg-0 px-3 px-lg-0">
        <a href="<?= base_url ('index.html') ?>" class="navbar-brand ms-lg-5">
            <h1 class="m-0 text-uppercase text-dark"><i class="bi bi-shop fs-1 text-primary me-3"></i>Toko Hewan</h1>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="<?= base_url('halo') ?>" class="nav-item nav-link">Home</a>
                <a href="<?= base_url ('user') ?>" class="nav-item nav-link active">CRUD</a>
                 <!-- <div class="nav-item dropdown">
                    <a href="<?= base_url ('#') ?>" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                    <div class="dropdown-menu m-0">
                        <a href="<?= base_url ('price.html') ?>" class="dropdown-item">Pricing Plan</a>
                        <a href="<?= base_url ('team.html') ?>" class="dropdown-item">The Team</a>
                        <a href="<?= base_url ('testimonial.html') ?>" class="dropdown-item">Testimonial</a>
                        <a href="<?= base_url ('blog.html') ?>" class="dropdown-item">Blog Grid</a>
                        <a href="<?= base_url ('detail.html') ?>" class="dropdown-item">Blog Detail</a>
                    </div> -->
                </div>
                <a href="https://instagram.com/faizihni?igshid=NzZlODBkYWE4Ng==" class="nav-item nav-link nav-contact bg-primary text-white px-5 ms-lg-5">Contact <i class="bi bi-arrow-right"></i></a>
            </div>
        </div>
    </nav>
    <br>
    <?php 
        if(isset($_GET['result'])){
            $result = '';
            if($_GET['result']==1)$result = 'Data Berhasil dihapus.';
            else $result = 'Data gagal dihapus.';
    ?>
    <div class="alert-success">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        <strong>Berhasil!</strong><?= $result ?>.
    </div>
    <br>
    <?php 
        }
    ?>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pengguna</th>
                <th>Nama</th>
                <th>Kata Sandi</th>
                <th>Peran</th>
                <th>Email</th>
                <th>No Telepon</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1;
                foreach($data_user as $row){
                echo '
                        <tr>
                            <td>' . $no . '</td>
                            <td>' . $row->username. '</td>
                            <td>' . $row->nama. '</td>
                            <td>' . $row->password. '</td>
                            <td>' . $row->role. '</td>
                            <td>' . $row->email. '</td>
                            <td>' . $row->telepon. '</td>
                            <td>
                            <a href="'.base_url('user/update_user').'/'.$row->username.'">Ubah</a>
                                 <a href="'.base_url('user/delete_user').'/'.$row->username.'" onclick="return confirm(\'Apakah Anda yakin ingin menghapus data ini?\');">Hapus</a>
                            </td>
                        </tr>
                    ';

                $no++;
            }
            ?>
        </tbody>
    </table>
    <form action="export.php" method="post">
        <input type="text" name="search" id="search" placeholder="Cari Data">
        <button name="export" class="btn btn-primary" type="submit">Export PDF</button>
    </form>
    <div class="jarakbutton">
        <a href="<?= base_url('user/add_user')?>">
            <button name="tambah" class="btn btn-primary" type="submit">Tambah Data</button>
        </a>
        <a href="Home.php">
            <button name="tambah" class="btn btn-danger" type="submit">Kembali</button>
        </a>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#example').DataTable();
        });
    </script>
</body>

</html>