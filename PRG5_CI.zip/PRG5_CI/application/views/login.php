<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        html {
            height: 100%;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            background: linear-gradient(#141e30, #2a6c56);
        }

        .login-box {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 400px;
            padding: 40px;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.5);
            box-sizing: border-box;
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.6);
            border-radius: 10px;
        }

        .login-box h2 {
            margin: 0 0 30px;
            padding: 0;
            color: transparent;
            text-align: center;
            background: linear-gradient(90deg, #03f484, #ffa500, #ff0000, #800080);
            background-size: 400% 400%;
            -webkit-background-clip: text;
            background-clip: text;
            animation: gradient 4s linear infinite;
        }

        @keyframes gradient {
            0% {
                background-position: 0 0;
            }
            100% {
                background-position: 100% 100%;
            }
        }

        .login-box .user-box {
            position: relative;
        }

        .login-box .user-box input {
            width: 100%;
            padding: 10px 0;
            font-size: 16px;
            color: #fff;
            margin-bottom: 30px;
            outline: none;
            background: transparent;
        }

        .login-box .user-box label {
            position: absolute;
            top: 0;
            left: 0;
            padding: 10px 0;
            font-size: 16px;
            color: #fff;
            pointer-events: none;
            transition: 0.5s;
        }

        .login-box .user-box input:focus~label,
        .login-box .user-box input:valid~label {
            top: -20px;
            left: 0;
            color: #03f484;
            font-size: 12px;
        }

        .login-box form .submit-button {
            display: inline-block;
            padding: 10px 20px;
            background: transparent;
            border: 2px solid #03f484;
            color: #03f484;
            font-size: 16px;
            text-decoration: none;
            text-transform: uppercase;
            border-radius: 5px;
            overflow: hidden;
            transition: 0.5s;
            margin-top: 40px;
            letter-spacing: 4px;
            cursor: pointer;
            position: relative;
        }

        .login-box form .submit-button:before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #03f484);
            animation: btn-anim1 1s linear infinite;
        }

        @keyframes btn-anim1 {
            0% {
                left: -100%;
            }
            50%, 100% {
                left: 100%;
            }
        }

        .login-box form .submit-button:after {
            content: "";
            position: absolute;
            top: -100%;
            right: 0;
            width: 2px;
            height: 100%;
            background: linear-gradient(180deg, transparent, #03f484);
            animation: btn-anim2 1s linear infinite;
            animation-delay: 0.25s;
        }

        @keyframes btn-anim2 {
            0% {
                top: -100%;
            }
            50%, 100% {
                top: 100%;
            }
        }

        .login-box form .submit-button:hover {
            background: #03f484;
            color: #fff;
            box-shadow: 0 0 5px #03f484, 0 0 25px #03f484, 0 0 50px #03f484, 0 0 100px #03f484;
        }
    </style>
</head>

<body>
    <div class="login-box">
        <h2>Form Login</h2>
        <form action="<?php echo site_url('login/ceklogin') ?>" method="post">
            <div class="user-box">
                <input type="text" name="username" required>
                <label for="">Nama Pengguna</label>
            </div>
            <div class="user-box">
                <input type="password" name="pass" required>
                <label for="">Kata Sandi</label>
            </div>
            <button class="submit-button" type="submit">Masuk</button>
        </form>
    </div>

</body>

</html>
