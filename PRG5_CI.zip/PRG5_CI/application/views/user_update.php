<!DOCTYPE html>
<html lang="en">

<head>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            background-color: #f7f7f7;
            /* Warna latar belakang */
        }

        .form-container {
            background-color: #ffffff;
            /* Warna latar belakang form */
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            /* Drop shadow */
            width: 400px;
            /* Sesuaikan lebar form sesuai kebutuhan */
        }

        .form-label {
            margin-bottom: 10px;
            /* Jarak antara label dan input */
        }
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Update Data User</title>
</head>
<body>  
    <?php if ($result) : ?>
        <div class="alert alert-success"><?php echo $result; ?></div>
    <?php endif; ?>
    <form method="post" action="">
            <div class="mb-3">
                <label for="username" class="form-label">Username :</label>
                <input type="text" class="form-control" name="username" value="<?= $data_user->username; ?>" required>
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Nama :</label>
                <input type="text" class="form-control" name="nama" value="<?= $data_user->nama; ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password :</label>
                <input type="text" class="form-control" name="password" value="<?= $data_user->password; ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email :</label>
                <input type="email" class="form-control" name="email" value="<?= $data_user->email; ?>" required>
            </div>
            <div class="mb-3">
                <select name="role" required>
                    <option value="">-- Pilih Salah Satu</option>
                    <option value="Admin" <?= $data_user->role === 'Admin' ? 'selected' : ''; ?>>Admin</option>
                    <option value="Dosen" <?= $data_user->role === 'Dosen' ? 'selected' : ''; ?>>Dosen</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="telepon" class="form-label">Telepon :</label>
                <input type="text" class="form-control" name="telepon" value="<?= $data_user->telepon; ?>" required>
            </div>
            <button name="update" class="btn btn-primary" type="submit">Update</button>
            <button name="reset" class="btn btn-secondary" type="reset">Reset</button>
        </form>
    </div>
</body>
</html>
