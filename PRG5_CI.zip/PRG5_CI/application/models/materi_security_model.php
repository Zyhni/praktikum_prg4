<?php 
    defined('BASEPATH') OR exit('No direct script access allowed');

class materi_security_model extends CI_Model
{
    private $_table = "akun";

    public function getAll()
	{
		return $this->db->get($this->_table)->result();
	}

    public function getByUsernamePassword()
    {
        $post1 = $this->input->post();
        $username = $post1["username"];
        $password = $post1["pass"];
        $query = $this->db->get_where($this->_table, array('username' => $username, 'password' => $password));
        return $query->row();
    }

    public function userInsert($data) {
        return $this->db->insert($this->_table,$data);
    }

    public function deleteUser($data) {
        $this->db->where('username', $data);
        $this->db->delete('akun'); // Ganti 'nama_tabel_user' dengan nama tabel yang sesuai di database Anda.
    
        return $this->db->affected_rows() > 0;
    }
    
    public function updateUser($user_id, $data) {
        $this->db->where('username', $user_id);
        return $this->db->update('akun', $data); // Ganti 'nama_tabel_user' dengan nama tabel yang sesuai di database Anda.
    }
    
    public function getUserById($user_id) {
        $this->db->where('username', $user_id);
        return $this->db->get('akun')->row();
    }
    
}
?>