<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {

	public function index()
	{
		$this->load->view('login');
	}

    public function __construct()
    {
        parent::__construct();
        $this->load->model("materi_security_model");
    }

    public function ceklogin()
    {
        $post = $this->input->post();
        if (isset($post["username"]) && isset($post["pass"])) {
            // Cek user
            $user = $this->materi_security_model->getByUsernamePassword();

            if ($user) {
                $username = $user->username;
                $name = $user->nama;
                $role = $user->role;

                $newdata = array(
                    'user_username' => $username,
                    'user_name' => $name,
                    'user_role' => $role
                );

                $this->session->set_userdata($newdata);

                if ($role == "Admin") {
                    redirect(site_url('halo'));
                } elseif ($role == "Dosen") {
                    // Role selain "Admin" akan diarahkan ke halaman kesalahan
                    echo "<script>alert('Anda tidak diizinkan mengakses halaman ini!'); window.location.href = '" . site_url('login') . "';</script>";
                } else {
                    // Role selain "Admin" dan "Dosen" akan mengalami error
                    echo "<script>alert('Anda tidak memiliki izin untuk mengakses sistem ini!'); window.location.href = '" . site_url('login') . "';</script>";
                }
            } else {
                echo "<script>alert('User atau password tidak terdaftar!'); window.location.href = '" . site_url('login') . "';</script>";
            }
        } else {
            $this->load->view("login");
        }
    }
}
