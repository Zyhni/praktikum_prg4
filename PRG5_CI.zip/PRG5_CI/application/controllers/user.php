<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class user extends CI_Controller {

function __construct(){
		parent::__construct();
		$this->load->model("materi_security_model");
	}

	public function index()
	{
		// get all user
		$user = $this->materi_security_model;
		$data['data_user'] = $user->getAll();
		$this->load->view('user_view', $data);
	}

    public function add_user(){
        $data['result'] = '';
        $post = $this->input->post();
        if (isset($post['simpan'])) {
            $data_user = array(
                'username'=>$post['username'],
                'nama'=>$post['nama'],
                'password'=>$post['password'],
                'role'=>$post['role'],
                'email'=>$post['email'],
                'telepon'=>$post['telepon']
            );
            $user = $this->materi_security_model;
            $result = $user->userInsert($data_user);
            if ($result) {
                $data['result'] = 'Data berhasil disimpan.';
            } else {
                $data['result'] = 'Data gagal disimpan';
            }
            $this->load->view('user_insert', $data);
        } else {
            $this->load->view('user_insert', $data);
        }
    }

    public function delete_user($user_id) {
        $user = $this->materi_security_model;
        $result = $user->deleteUser($user_id);
    
        if ($result) {
            $data['result'] = 'Data berhasil dihapus.';
        } else {
            $data['result'] = 'Data gagal dihapus.';
        }
    
        // Setelah menghapus data, Anda bisa mengarahkan pengguna kembali ke halaman daftar pengguna.
        $data['data_user'] = $user->getAll();
        $this->load->view('user_view', $data);
    }
    
    public function update_user($user_id) {
        $data['result'] = '';
    
        if ($this->input->post('update')) {
            $post = $this->input->post();
            $data_user = array(
                'username' => $post['username'],
                'nama' => $post['nama'],
                'password' => $post['password'],
                'role' => $post['role'],
                'email' => $post['email'],
                'telepon' => $post['telepon']
            );
    
            $user = $this->materi_security_model;
            $result = $user->updateUser($user_id, $data_user);
    
            if ($result) {
                $data['result'] = 'Data berhasil diperbarui.';
    
                // Setelah berhasil diperbarui, arahkan kembali ke tampilan user_view.
                redirect('user');
            } else {
                $data['result'] = 'Data gagal diperbarui.';
            }
        }
    
        // Mengambil data pengguna yang akan diperbarui.
        $user = $this->materi_security_model;
        $data['data_user'] = $user->getUserById($user_id);
    
        $this->load->view('user_update', $data);
    }   
}